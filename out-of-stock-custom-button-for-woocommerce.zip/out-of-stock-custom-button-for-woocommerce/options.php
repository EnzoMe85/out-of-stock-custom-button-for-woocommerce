<?php
function ocbw_custom_button_options_page()
{
    add_options_page(
        'Out of Stock Custom Button Settings',
        'Custom Button Settings',
        'manage_options',
        'ocbw-custom-button',
        'ocbw_custom_button_options_page_html'
    );
}
add_action('admin_menu', 'ocbw_custom_button_options_page');

function ocbw_custom_button_settings_init()
{
    register_setting('ocbw_custom_button_options', 'ocbw_custom_button_text');
    register_setting('ocbw_custom_button_options', 'ocbw_custom_button_color');
    register_setting('ocbw_custom_button_options', 'ocbw_custom_button_text_color');
    register_setting('ocbw_custom_button_options', 'ocbw_custom_button_link');
    register_setting('ocbw_custom_button_options', 'ocbw_custom_button_border_radius');
}
add_action('admin_init', 'ocbw_custom_button_settings_init');

function ocbw_custom_button_options_page_html()
{
?>
    <div class="wrap">
        <h1>Custom Button Settings</h1>
        <form action="options.php" method="post">
            <?php settings_fields('ocbw_custom_button_options'); ?>
            <?php do_settings_sections('ocbw_custom_button_options'); ?>
            <table class="form-table">
                <tr valign="top">
                    <th scope="row"><label for="ocbw_custom_button_text"><?php _e('Button Text', 'ocbw_custom_button'); ?></label></th>
                    <td><input type="text" name="ocbw_custom_button_text" id="ocbw_custom_button_text" value="<?php echo esc_attr(get_option('ocbw_custom_button_text')); ?>" /></td>
                </tr>
                <tr valign="top">
                    <th scope="row"><label for="ocbw_custom_button_color"><?php _e('Button Background Color', 'ocbw_custom_button'); ?></label></th>
                    <td><input type="text" class="my-color-field" name="ocbw_custom_button_color" id="ocbw_custom_button_color" value="<?php echo esc_attr(get_option('ocbw_custom_button_color')); ?>" /></td>
                </tr>
                <tr valign="top">
                    <th scope="row"><label for="ocbw_custom_button_text_color"><?php _e('Button Text Color', 'ocbw_custom_button'); ?></label></th>
                    <td><input type="text" class="my-color-field" name="ocbw_custom_button_text_color" id="ocbw_custom_button_text_color" value="<?php echo esc_attr(get_option('ocbw_custom_button_text_color')); ?>" /></td>
                </tr>
                <tr valign="top">
                    <th scope="row"><label for="ocbw_custom_button_link"><?php _e('Button Link', 'ocbw_custom_button'); ?></label></th>
                    <td><input type="text" name="ocbw_custom_button_link" id="ocbw_custom_button_link" value="<?php echo esc_attr(get_option('ocbw_custom_button_link')); ?>" /></td>
                </tr>

                <tr valign="top">
                    <th scope="row"><label for="ocbw_custom_button_border_radius"><?php _e('Button Border Radius', 'ocbw_custom_button'); ?></label></th>
                    <td><input type="text" name="ocbw_custom_button_border_radius" id="ocbw_custom_button_border_radius" value="<?php echo esc_attr(get_option('ocbw_custom_button_border_radius')); ?>" /></td>
                </tr>
            </table>
            <?php submit_button(); ?>
        </form>
    </div>
<?php
}
